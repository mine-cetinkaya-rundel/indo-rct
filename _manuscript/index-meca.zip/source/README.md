[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/mine-cetinkaya-rundel/indo-rct/HEAD)

This is a Quarto reproduction of a paper published in the New England Journal of Medicine in 2012, which you can find at <https://www.nejm.org/doi/full/10.1056/NEJMoa1111103>.
Some of the reproduction code was provided by Peter Higgins.
